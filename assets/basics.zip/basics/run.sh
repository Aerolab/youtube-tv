#! /bin/bash
./build/cache/mac/0.10.5/node-webkit-v0.10.5-osx-ia32/node-webkit.app/Contents/MacOS/node-webkit ./ --debug
