/**
 * This is the core of our Remote Control
 */
