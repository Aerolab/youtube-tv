/**
 * This is going to be the core of our desktop app.
 */

